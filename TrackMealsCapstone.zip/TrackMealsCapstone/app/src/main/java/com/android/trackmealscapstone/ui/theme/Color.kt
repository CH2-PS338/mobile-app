package com.android.trackmealscapstone.ui.theme

import androidx.compose.ui.graphics.Color

val orangePrimary = Color(0xFFF08000)
val orangeSecondary = Color(0xFFC46900)